package com.webcrawler.collector;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.net.UnknownHostException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.Test;

public class PageCollectorTest {

    @Test
    public void shouldNotReturnException() throws UnknownHostException, IOException {
        PageCollector pageCollector = new PageCollector("http://en.wikipedia.org");
        assertNotNull(pageCollector);
        assertNotNull(pageCollector.getDocument());
    }

    @Test(expected = UnknownHostException.class)
    public void shouldNotConstructAndReturnException() throws UnknownHostException, IOException {
        new PageCollector("http://en.wrongurl.org");
    }

    @Test
    public void test() throws IOException {
        Document document = Jsoup.connect("http://en.wikipedia.org").get();
        Elements docElements = document.select("a[href]");

        for (Element element : docElements) {
            System.out.println(element);
            // https://jsoup.org/cookbook/extracting-data/example-list-links
        }
        Elements headerTags = document.select("h1, h2, h3, h4, h5, h6");
        Elements h1Tags = headerTags.select("h1");
        System.out.println("Header ************");
        System.out.println(h1Tags);
        System.out.println(headerTags.select("h2"));
        System.out.println(headerTags.select("h3"));
    }

}
