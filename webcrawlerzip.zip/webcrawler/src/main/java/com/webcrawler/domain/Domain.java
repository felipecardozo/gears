package com.webcrawler.domain;

import java.sql.Timestamp;

public class Domain {

    private String hash;
    private String url;
    private Timestamp created;


    public Domain(String hash, String url, Timestamp created) {
        this.hash = hash;
        this.url = url;
        this.created = created;
    }

    public String getHash() {
        return hash;
    }

    public String getUrl() {
        return url;
    }

    public Timestamp getCreated() {
        return created;
    }

}
