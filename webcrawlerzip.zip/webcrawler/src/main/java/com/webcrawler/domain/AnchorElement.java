package com.webcrawler.domain;

import java.sql.Timestamp;

public class AnchorElement {

    private Domain domain;
    private int status;
    private Timestamp created;



    public AnchorElement(Domain domain, int status, Timestamp created) {
        super();
        this.domain = domain;
        this.status = status;
        this.created = created;
    }

    public Domain getDomain() {
        return domain;
    }

    public int getStatus() {
        return status;
    }

    public Timestamp getCreated() {
        return created;
    }


}
