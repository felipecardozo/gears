package com.webcrawler.domain;

public class Page {

    private AnchorElement anchor;
    private String webPage;
    private int status;

    public Page(AnchorElement anchor, String webPage, int status) {
        super();
        this.anchor = anchor;
        this.webPage = webPage;
        this.status = status;
    }

    public AnchorElement getAnchor() {
        return anchor;
    }

    public String getWebPage() {
        return webPage;
    }

    public int getStatus() {
        return status;
    }



}
