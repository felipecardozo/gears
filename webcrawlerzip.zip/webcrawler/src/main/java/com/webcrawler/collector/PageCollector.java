package com.webcrawler.collector;

import java.io.IOException;
import java.net.UnknownHostException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class PageCollector {
	
	private String url;
	private Document document;
	
	public PageCollector(String url) throws UnknownHostException, IOException{
		this.url = url;
		this.document = Jsoup.connect(url).get();
	}
	
	public String getUrl(String url){
		return url;
	}
	
	public Document getDocument(){
		return document;
	}

}
